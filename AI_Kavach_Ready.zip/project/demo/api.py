"""
AI Kavach — Backend API

Exposes the full detection pipeline as explicit, visible stages, so the
system is as legible on the backend as it is on the frontend:

    1. MODEL LOADING     — load backbone + LoRA adapter + classifier head once at startup
    2. PREPROCESSING      — resample, mono-mix, pad/trim, feature-extract
    3. INFERENCE          — forward pass through the model
    4. PREDICTION         — turn logits into a label + risk score
    5. EXPLANATION        — turn the prediction into human-readable signals

Run with:
    uvicorn api:app --reload --port 8000

Then POST an audio file to http://localhost:8000/analyze
(the demo HTML's scoreAudio() function should point here instead of its mock).

If no trained checkpoint exists yet at --model_dir, the server still starts
and clearly reports that in every response's "model_status" field, rather
than silently returning fake numbers — so the mentor sees exactly what
stage of the project you're at.
"""

import logging
import os
import shutil
import tempfile
from contextlib import asynccontextmanager

import torch
import torch.nn as nn
import torchaudio
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2Model
from peft import PeftModel

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
MODEL_NAME = "facebook/wav2vec2-large-xlsr-53"
MODEL_DIR = os.environ.get("AI_KAVACH_MODEL_DIR", "./checkpoints")
SAMPLE_RATE = 16000
MAX_SECONDS = 6
LABELS = {0: "authentic", 1: "synthetic"}

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("ai_kavach")


# --------------------------------------------------------------------------
# STAGE 1 — MODEL LOADING
# --------------------------------------------------------------------------
class ModelBundle:
    """
    Holds every component the pipeline needs, loaded once at server startup
    rather than per-request (loading a transformer from disk on every call
    would make "real-time" impossible).
    """

    def __init__(self):
        self.feature_extractor = None
        self.backbone = None
        self.classifier = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.is_trained = False

    def load(self, model_dir: str):
        log.info(f"STAGE 1 [MODEL LOADING] — device={self.device}")
        log.info(f"STAGE 1 [MODEL LOADING] — loading base model '{MODEL_NAME}'...")

        self.feature_extractor = Wav2Vec2FeatureExtractor.from_pretrained(MODEL_NAME)
        base_model = Wav2Vec2Model.from_pretrained(MODEL_NAME)

        adapter_path = os.path.join(model_dir, "lora_adapter")
        head_path = os.path.join(model_dir, "classifier_head.pt")

        if os.path.isdir(adapter_path) and os.path.isfile(head_path):
            log.info(f"STAGE 1 [MODEL LOADING] — found trained checkpoint at '{model_dir}', loading LoRA adapter + classifier head")
            self.backbone = PeftModel.from_pretrained(base_model, adapter_path).to(self.device)
            self.classifier = Classifier(base_model.config.hidden_size).to(self.device)
            self.classifier.load_state_dict(torch.load(head_path, map_location=self.device))
            self.is_trained = True
        else:
            log.warning(
                f"STAGE 1 [MODEL LOADING] — no trained checkpoint found at '{model_dir}'. "
                f"Serving with an UNTRAINED classifier head as a placeholder — "
                f"predictions will not be meaningful until train_lora.py has been run."
            )
            self.backbone = base_model.to(self.device)
            self.classifier = Classifier(base_model.config.hidden_size).to(self.device)
            self.is_trained = False

        self.backbone.eval()
        self.classifier.eval()
        log.info("STAGE 1 [MODEL LOADING] — done.")


class Classifier(nn.Module):
    """Small trained head on top of the frozen/LoRA-adapted backbone."""

    def __init__(self, hidden_size):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 2),
        )

    def forward(self, x):
        return self.net(x)


model_bundle = ModelBundle()


@asynccontextmanager
async def lifespan(app: FastAPI):
    model_bundle.load(MODEL_DIR)
    yield


app = FastAPI(title="AI Kavach API", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # fine for a local demo; restrict in real deployment
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------------------------------
# STAGE 2 — PREPROCESSING
# --------------------------------------------------------------------------
def preprocess_audio(audio_path: str) -> torch.Tensor:
    """
    Loads a raw audio file and turns it into the fixed-shape tensor the model
    expects: mono, 16kHz, padded/trimmed to MAX_SECONDS.
    """
    log.info(f"STAGE 2 [PREPROCESSING] — loading '{audio_path}'")
    waveform, sr = torchaudio.load(audio_path)

    if sr != SAMPLE_RATE:
        log.info(f"STAGE 2 [PREPROCESSING] — resampling {sr}Hz -> {SAMPLE_RATE}Hz")
        waveform = torchaudio.functional.resample(waveform, sr, SAMPLE_RATE)

    waveform = waveform.mean(dim=0)  # mono-mix if stereo
    log.info(f"STAGE 2 [PREPROCESSING] — mono-mixed, raw length={waveform.shape[0]} samples")

    max_len = SAMPLE_RATE * MAX_SECONDS
    if waveform.shape[0] > max_len:
        waveform = waveform[:max_len]
        log.info(f"STAGE 2 [PREPROCESSING] — trimmed to {MAX_SECONDS}s")
    else:
        pad = max_len - waveform.shape[0]
        waveform = torch.nn.functional.pad(waveform, (0, pad))
        log.info(f"STAGE 2 [PREPROCESSING] — padded with {pad} zero-samples to reach {MAX_SECONDS}s")

    return waveform


# --------------------------------------------------------------------------
# STAGE 3 — INFERENCE
# --------------------------------------------------------------------------
def run_inference(waveform: torch.Tensor) -> torch.Tensor:
    """Runs the preprocessed waveform through the backbone + classifier, returns raw logits."""
    log.info("STAGE 3 [INFERENCE] — extracting features")
    inputs = model_bundle.feature_extractor(
        [waveform.numpy()], sampling_rate=SAMPLE_RATE, return_tensors="pt", padding=True
    )
    input_values = inputs.input_values.to(model_bundle.device)

    log.info("STAGE 3 [INFERENCE] — forward pass through Wav2Vec2-XLSR (+ LoRA)")
    with torch.no_grad():
        hidden = model_bundle.backbone(input_values).last_hidden_state.mean(dim=1)
        logits = model_bundle.classifier(hidden)

    log.info(f"STAGE 3 [INFERENCE] — raw logits={logits.squeeze().tolist()}")
    return logits


# --------------------------------------------------------------------------
# STAGE 4 — PREDICTION
# --------------------------------------------------------------------------
def make_prediction(logits: torch.Tensor) -> dict:
    """Converts raw logits into a label + a 0-100 risk score."""
    probs = torch.softmax(logits, dim=-1).squeeze().cpu().numpy()
    pred_label = int(probs.argmax())
    result = {
        "label": LABELS[pred_label],
        "risk_score": round(float(probs[1]) * 100, 1),  # probability of being synthetic
        "raw_probs": {"authentic": round(float(probs[0]), 4), "synthetic": round(float(probs[1]), 4)},
    }
    log.info(f"STAGE 4 [PREDICTION] — label={result['label']} risk_score={result['risk_score']}")
    return result


# --------------------------------------------------------------------------
# STAGE 5 — EXPLANATION
# --------------------------------------------------------------------------
def generate_explanation(prediction: dict) -> list:
    """
    Turns the numeric prediction into human-readable acoustic signals.

    NOTE: today this maps the verdict to representative signal descriptions.
    A stronger version (good stretch goal) would compute real per-signal
    sub-scores — e.g. a phase-anomaly score from spectral analysis, a
    prosody-variance score from pitch contour — rather than inferring
    signals purely from the final label.
    """
    is_fake = prediction["label"] == "synthetic"
    signals = (
        ["Spectral phase anomaly detected", "Vocoder stitching artifact present", "Mechanized prosody (low rhythm variance)"]
        if is_fake
        else ["Natural spectral variance", "No vocoder artifacts detected", "Organic prosody and breath pattern"]
    )
    log.info(f"STAGE 5 [EXPLANATION] — signals={signals}")
    return signals


# --------------------------------------------------------------------------
# API endpoint — runs all five stages in order
# --------------------------------------------------------------------------
@app.post("/analyze")
async def analyze(audio: UploadFile = File(...)):
    with tempfile.NamedTemporaryFile(suffix=os.path.splitext(audio.filename)[-1], delete=False) as tmp:
        shutil.copyfileobj(audio.file, tmp)
        tmp_path = tmp.name

    try:
        waveform = preprocess_audio(tmp_path)          # Stage 2
        logits = run_inference(waveform)                # Stage 3
        prediction = make_prediction(logits)            # Stage 4
        signals = generate_explanation(prediction)      # Stage 5

        return {
            **prediction,
            "signals": signals,
            "model_status": "trained" if model_bundle.is_trained else "UNTRAINED_PLACEHOLDER — run train_lora.py first",
        }
    finally:
        os.remove(tmp_path)


@app.get("/health")
async def health():
    """Quick check that the server and model loaded correctly."""
    return {
        "status": "ok",
        "device": str(model_bundle.device),
        "model_trained": model_bundle.is_trained,
        "model_dir": MODEL_DIR,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
