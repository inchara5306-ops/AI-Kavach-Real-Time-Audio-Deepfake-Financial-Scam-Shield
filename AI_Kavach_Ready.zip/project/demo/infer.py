"""
AI Kavach — Step 3: Run the trained detector on a single audio file.

Usage:
    python infer.py --model_dir ./checkpoints --audio_file sample.wav

Also importable as a function (`score_audio`) so you can wrap it in a small
Flask/FastAPI server for the live demo (see demo/app.html).
"""

import argparse
import json
import os

import torch
import torch.nn as nn
import torchaudio
from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2Model
from peft import PeftModel

MODEL_NAME = "facebook/wav2vec2-large-xlsr-53"
SAMPLE_RATE = 16000
MAX_SECONDS = 6
LABELS = {0: "authentic", 1: "synthetic"}


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model_dir", type=str, required=True)
    p.add_argument("--audio_file", type=str, required=True)
    return p.parse_args()


class Classifier(nn.Module):
    def __init__(self, hidden_size):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 2),
        )

    def forward(self, x):
        return self.net(x)


_cached = {}


def load_model(model_dir, device):
    if model_dir in _cached:
        return _cached[model_dir]

    feature_extractor = Wav2Vec2FeatureExtractor.from_pretrained(MODEL_NAME)
    base_model = Wav2Vec2Model.from_pretrained(MODEL_NAME)
    backbone = PeftModel.from_pretrained(base_model, os.path.join(model_dir, "lora_adapter")).to(device)
    backbone.eval()

    classifier = Classifier(base_model.config.hidden_size).to(device)
    classifier.load_state_dict(torch.load(os.path.join(model_dir, "classifier_head.pt"), map_location=device))
    classifier.eval()

    _cached[model_dir] = (feature_extractor, backbone, classifier)
    return _cached[model_dir]


def score_audio(model_dir: str, audio_path: str) -> dict:
    """Returns {'label': str, 'risk_score': float 0-100, 'raw_probs': [p_real, p_fake]}"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    feature_extractor, backbone, classifier = load_model(model_dir, device)

    waveform, sr = torchaudio.load(audio_path)
    if sr != SAMPLE_RATE:
        waveform = torchaudio.functional.resample(waveform, sr, SAMPLE_RATE)
    waveform = waveform.mean(dim=0)

    max_len = SAMPLE_RATE * MAX_SECONDS
    if waveform.shape[0] > max_len:
        waveform = waveform[:max_len]
    else:
        waveform = torch.nn.functional.pad(waveform, (0, max_len - waveform.shape[0]))

    inputs = feature_extractor([waveform.numpy()], sampling_rate=SAMPLE_RATE, return_tensors="pt", padding=True)
    input_values = inputs.input_values.to(device)

    with torch.no_grad():
        hidden = backbone(input_values).last_hidden_state.mean(dim=1)
        logits = classifier(hidden)
        probs = torch.softmax(logits, dim=-1).squeeze().cpu().numpy()

    pred_label = int(probs.argmax())
    return {
        "label": LABELS[pred_label],
        "risk_score": round(float(probs[1]) * 100, 1),  # probability of being synthetic
        "raw_probs": {"authentic": round(float(probs[0]), 4), "synthetic": round(float(probs[1]), 4)},
    }


if __name__ == "__main__":
    args = parse_args()
    result = score_audio(args.model_dir, args.audio_file)
    print(json.dumps(result, indent=2))
