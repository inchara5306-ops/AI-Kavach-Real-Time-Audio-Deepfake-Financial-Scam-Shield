@echo off
echo === Checking GPU ===
nvidia-smi

echo === Creating virtual environment ===
python -m venv venv
call venv\Scripts\activate

echo === Installing dependencies (this takes a few minutes) ===
pip install torch torchaudio transformers peft datasets soundfile librosa accelerate evaluate scikit-learn fastapi uvicorn python-multipart

echo === Building dataset ===
python data\data_prep.py --languages hi_in --samples_per_lang 150 --out_dir .\dataset

echo === Training model (basic, fast settings) ===
python training\train_lora.py --data_dir .\dataset --output_dir .\checkpoints --epochs 2

echo === Starting live API server ===
echo Once you see "Uvicorn running on http://127.0.0.1:8000" below, open demo\app.html in your browser - it will connect automatically.
uvicorn demo.api:app --port 8000
