"""
AI Kavach — Step 2: Fine-tune Wav2Vec2-XLSR with LoRA for real-vs-synthetic
audio classification.

This is the script you run during your H200 lab time (Day 7's LoRA/PEFT module
maps directly onto this, and Day 9 is where you'd apply the mixed-precision /
optimization tricks).

Usage:
    python train_lora.py --data_dir ./dataset --output_dir ./checkpoints --epochs 5
"""

import argparse
import json
import os

import numpy as np
import torch
import torch.nn as nn
import torchaudio
from torch.utils.data import Dataset, DataLoader
from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2Model, get_linear_schedule_with_warmup
from peft import LoraConfig, get_peft_model
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score
import pandas as pd


MODEL_NAME = "facebook/wav2vec2-large-xlsr-53"
SAMPLE_RATE = 16000
MAX_SECONDS = 6


def parse_args():
    p = argparse.ArgumentParser(description="Fine-tune Wav2Vec2-XLSR for deepfake audio detection")
    p.add_argument("--data_dir", type=str, required=True, help="Folder containing train.csv/val.csv/test.csv")
    p.add_argument("--output_dir", type=str, default="./checkpoints")
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--lora_r", type=int, default=8)
    p.add_argument("--lora_alpha", type=int, default=16)
    p.add_argument("--fp16", action="store_true", default=True,
                    help="Use mixed precision (recommended on H200)")
    return p.parse_args()


class AudioSpoofDataset(Dataset):
    """Loads (waveform, label) pairs from a manifest CSV."""

    def __init__(self, csv_path, feature_extractor):
        self.df = pd.read_csv(csv_path)
        self.feature_extractor = feature_extractor

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        waveform, sr = torchaudio.load(row["path"])
        if sr != SAMPLE_RATE:
            waveform = torchaudio.functional.resample(waveform, sr, SAMPLE_RATE)
        waveform = waveform.mean(dim=0)  # mono

        max_len = SAMPLE_RATE * MAX_SECONDS
        if waveform.shape[0] > max_len:
            waveform = waveform[:max_len]
        else:
            waveform = torch.nn.functional.pad(waveform, (0, max_len - waveform.shape[0]))

        return waveform, int(row["label"])


def collate(batch, feature_extractor):
    waveforms, labels = zip(*batch)
    inputs = feature_extractor(
        [w.numpy() for w in waveforms],
        sampling_rate=SAMPLE_RATE,
        return_tensors="pt",
        padding=True,
    )
    return inputs.input_values, torch.tensor(labels, dtype=torch.long)


class DeepfakeDetector(nn.Module):
    """Wav2Vec2-XLSR backbone (LoRA-adapted) + a small classification head."""

    def __init__(self, lora_r=8, lora_alpha=16):
        super().__init__()
        base_model = Wav2Vec2Model.from_pretrained(MODEL_NAME)

        # LoRA is applied to the attention projection layers of the transformer,
        # which is the same idea covered in the program's PEFT/LoRA lab (Day 7) —
        # here it's just applied to an audio backbone instead of a text LLM.
        lora_config = LoraConfig(
            r=lora_r,
            lora_alpha=lora_alpha,
            target_modules=["q_proj", "v_proj"],
            lora_dropout=0.1,
            bias="none",
        )
        self.backbone = get_peft_model(base_model, lora_config)

        hidden_size = base_model.config.hidden_size
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 2),  # 0 = real, 1 = synthetic
        )

    def forward(self, input_values):
        outputs = self.backbone(input_values).last_hidden_state  # (B, T, H)
        pooled = outputs.mean(dim=1)  # mean-pool over time
        return self.classifier(pooled)


def evaluate(model, loader, device):
    model.eval()
    all_labels, all_preds, all_probs = [], [], []
    with torch.no_grad():
        for input_values, labels in loader:
            input_values, labels = input_values.to(device), labels.to(device)
            logits = model(input_values)
            probs = torch.softmax(logits, dim=-1)[:, 1]
            preds = torch.argmax(logits, dim=-1)
            all_labels.extend(labels.cpu().numpy())
            all_preds.extend(preds.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())

    acc = accuracy_score(all_labels, all_preds)
    f1 = f1_score(all_labels, all_preds)
    try:
        auc = roc_auc_score(all_labels, all_probs)
    except ValueError:
        auc = float("nan")  # happens if a split has only one class

    # Equal Error Rate (EER) — the standard anti-spoofing metric
    from scipy.optimize import brentq
    from scipy.interpolate import interp1d
    from sklearn.metrics import roc_curve
    fpr, tpr, _ = roc_curve(all_labels, all_probs)
    try:
        eer = brentq(lambda x: 1. - x - interp1d(fpr, tpr)(x), 0., 1.)
    except Exception:
        eer = float("nan")

    return {"accuracy": acc, "f1": f1, "auc": auc, "eer": eer}


def main():
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[train] Using device: {device}")
    os.makedirs(args.output_dir, exist_ok=True)

    feature_extractor = Wav2Vec2FeatureExtractor.from_pretrained(MODEL_NAME)

    train_ds = AudioSpoofDataset(os.path.join(args.data_dir, "train.csv"), feature_extractor)
    val_ds = AudioSpoofDataset(os.path.join(args.data_dir, "val.csv"), feature_extractor)
    test_ds = AudioSpoofDataset(os.path.join(args.data_dir, "test.csv"), feature_extractor)

    collate_fn = lambda b: collate(b, feature_extractor)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, collate_fn=collate_fn)
    test_loader = DataLoader(test_ds, batch_size=args.batch_size, collate_fn=collate_fn)

    model = DeepfakeDetector(lora_r=args.lora_r, lora_alpha=args.lora_alpha).to(device)
    model.backbone.print_trainable_parameters()  # shows how small the LoRA footprint is

    optimizer = torch.optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr)
    total_steps = len(train_loader) * args.epochs
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=int(0.1 * total_steps), num_training_steps=total_steps)
    criterion = nn.CrossEntropyLoss()
    scaler = torch.cuda.amp.GradScaler(enabled=args.fp16)

    best_val_f1 = -1
    for epoch in range(args.epochs):
        model.train()
        running_loss = 0.0
        for input_values, labels in train_loader:
            input_values, labels = input_values.to(device), labels.to(device)
            optimizer.zero_grad()

            with torch.cuda.amp.autocast(enabled=args.fp16):
                logits = model(input_values)
                loss = criterion(logits, labels)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            running_loss += loss.item()

        val_metrics = evaluate(model, val_loader, device)
        print(f"[train] Epoch {epoch+1}/{args.epochs} — loss={running_loss/len(train_loader):.4f} "
              f"val_acc={val_metrics['accuracy']:.3f} val_f1={val_metrics['f1']:.3f} val_eer={val_metrics['eer']:.3f}")

        if val_metrics["f1"] > best_val_f1:
            best_val_f1 = val_metrics["f1"]
            model.backbone.save_pretrained(os.path.join(args.output_dir, "lora_adapter"))
            torch.save(model.classifier.state_dict(), os.path.join(args.output_dir, "classifier_head.pt"))
            print(f"[train] Saved new best checkpoint (val_f1={best_val_f1:.3f})")

    test_metrics = evaluate(model, test_loader, device)
    print(f"[train] FINAL TEST METRICS: {test_metrics}")
    with open(os.path.join(args.output_dir, "metrics.json"), "w") as f:
        json.dump(test_metrics, f, indent=2)


if __name__ == "__main__":
    main()
