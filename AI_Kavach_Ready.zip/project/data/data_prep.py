"""
AI Kavach — Dataset preparation (fast, local, no downloads).

Builds a labeled real-vs-synthetic audio dataset by:
  1. Pulling real human speech from Google FLEURS.
  2. Generating "synthetic-like" fakes via audio signal distortion
     (pitch shift + time stretch + light spectral distortion) — mimics
     artifacts common in cloned/synthetic voices without needing a
     multi-GB TTS model download.
  3. Writing a manifest CSV + train/val/test split.

Usage:
    python data_prep.py --languages hi_in --samples_per_lang 300 --out_dir ./dataset
"""

import argparse
import csv
import random
from pathlib import Path

import numpy as np
import soundfile as sf
import librosa

LABEL_REAL = 0
LABEL_SYNTHETIC = 1


def parse_args():
    p = argparse.ArgumentParser(description="Prepare AI Kavach training dataset")
    p.add_argument("--languages", nargs="+", default=["hi_in"])
    p.add_argument("--samples_per_lang", type=int, default=300)
    p.add_argument("--clone_fraction", type=float, default=0.5)
    p.add_argument("--out_dir", type=str, default="./dataset")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


def load_common_voice(language: str, n_samples: int, cache_dir: str):
    from datasets import load_dataset
    print(f"[data_prep] Loading FLEURS ({language})...")
    ds = load_dataset("google/fleurs", language, split="train", streaming=True, cache_dir=cache_dir)
    samples = []
    for i, row in enumerate(ds):
        if i >= n_samples:
            break
        samples.append({
            "audio": row["audio"],
            "sentence": row["transcription"],
            "language": language,
        })
    print(f"[data_prep] Got {len(samples)} real clips for '{language}'.")
    return samples


def clone_voice(reference_audio_array, sampling_rate, text, language):
    """Fast fake-audio generator via signal distortion (no model download)."""
    y = reference_audio_array.astype(np.float32)
    n_steps = random.choice([-2, -1, 1, 2])
    y_shifted = librosa.effects.pitch_shift(y, sr=sampling_rate, n_steps=n_steps)
    rate = random.choice([0.92, 0.96, 1.04, 1.08])
    y_stretched = librosa.effects.time_stretch(y_shifted, rate=rate)
    noise = np.random.normal(0, 0.002, y_stretched.shape[0])
    y_final = np.clip(y_stretched + noise, -1.0, 1.0)
    return y_final, sampling_rate


def build_dataset(args):
    out_dir = Path(args.out_dir)
    audio_dir = out_dir / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)
    random.seed(args.seed)

    manifest = []
    clip_id = 0

    for lang in args.languages:
        real_samples = load_common_voice(lang, args.samples_per_lang, cache_dir=str(out_dir / ".cache"))
        n_to_clone = int(len(real_samples) * args.clone_fraction)
        to_clone = set(random.sample(range(len(real_samples)), n_to_clone)) if n_to_clone else set()

        for i, sample in enumerate(real_samples):
            arr = sample["audio"]["array"]
            sr = sample["audio"]["sampling_rate"]

            real_path = audio_dir / f"{lang}_{clip_id:05d}_real.wav"
            sf.write(real_path, arr, sr)
            manifest.append({"path": str(real_path), "label": LABEL_REAL, "language": lang})
            clip_id += 1

            if i in to_clone:
                try:
                    cloned_arr, cloned_sr = clone_voice(arr, sr, sample["sentence"], lang)
                    fake_path = audio_dir / f"{lang}_{clip_id:05d}_fake.wav"
                    sf.write(fake_path, cloned_arr, cloned_sr)
                    manifest.append({"path": str(fake_path), "label": LABEL_SYNTHETIC, "language": lang})
                    clip_id += 1
                except Exception as e:
                    print(f"[data_prep] Skipping clone for sample {i} ({lang}): {e}")

    random.shuffle(manifest)
    n = len(manifest)
    n_train = int(n * 0.8)
    n_val = int(n * 0.1)
    splits = {
        "train": manifest[:n_train],
        "val": manifest[n_train:n_train + n_val],
        "test": manifest[n_train + n_val:],
    }

    for split_name, rows in splits.items():
        csv_path = out_dir / f"{split_name}.csv"
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["path", "label", "language"])
            writer.writeheader()
            writer.writerows(rows)
        print(f"[data_prep] Wrote {len(rows)} rows -> {csv_path}")

    print(f"[data_prep] Done. Total clips: {n} "
          f"(real={sum(1 for r in manifest if r['label']==LABEL_REAL)}, "
          f"synthetic={sum(1 for r in manifest if r['label']==LABEL_SYNTHETIC)})")


if __name__ == "__main__":
    args = parse_args()
    build_dataset(args)
