# AI Kavach — Real-Time Audio Deepfake & Financial Scam Shield

A voice-clone / audio-deepfake detector fine-tuned for Indian languages (Hindi, Kannada, Tamil),
built to run on the program's H200 GPU cluster.

## What's in this folder

```
code/
├── data/
│   └── data_prep.py       # Step 1: build the training dataset
├── training/
│   └── train_lora.py      # Step 2: fine-tune Wav2Vec2-XLSR with LoRA on the H200
├── demo/
│   ├── infer.py            # Step 3: run the trained model on a single audio file
│   └── app.html             # Step 4: browser demo (risk-score UI) for your presentation
└── README.md
```

## You don't need to understand ML to use this — just follow the order below

### Step 0 — On your JupyterHub H200 container, install dependencies once
```bash
pip install torch torchaudio transformers peft datasets soundfile librosa accelerate evaluate scikit-learn
```

### Step 1 — Build the dataset (`data/data_prep.py`)
This script:
1. Downloads a small slice of Mozilla Common Voice in Hindi/Kannada/Tamil (real speech — label `0`).
2. Uses an open TTS model to clone a handful of those voices (fake speech — label `1`).
3. Mixes in the ASVspoof dataset (general spoof patterns) if you have access to it.
4. Saves everything as a labeled CSV + audio folder, split into train/val/test.

Run it:
```bash
python data/data_prep.py --languages hi kn ta --samples_per_lang 300 --out_dir ./dataset
```
This can take a while (downloading + generating clones) — start it on Day 2–4, not Day 9.

### Step 2 — Fine-tune the model (`training/train_lora.py`)
This is the part that actually needs the H200. It:
1. Loads `facebook/wav2vec2-xlsr-53` (or `wav2vec2-large-xlsr-53`) as a frozen backbone.
2. Attaches a small LoRA adapter + classification head (real vs. fake).
3. Trains with mixed precision (fp16/bf16) for speed — this is the technique from your
   "GPU Optimization" module (Day 9), reused here directly.
4. Saves the fine-tuned adapter + a `metrics.json` with your EER/accuracy/F1 numbers.

Run it (during your Day 7 or Day 9 lab session):
```bash
python training/train_lora.py --data_dir ./dataset --output_dir ./checkpoints --epochs 5
```

### Step 3 — Test it on one file (`demo/infer.py`)
```bash
python demo/infer.py --model_dir ./checkpoints --audio_file sample.wav
# -> {"label": "synthetic", "risk_score": 87.4, "language_guess": "hi"}
```

### Step 3.5 — Run the real backend API (`demo/api.py`)
This is what actually connects your trained model to the demo pages. Unlike
`infer.py` (which is for one-off testing), `api.py` is a proper backend server
that makes every pipeline stage explicit and logged — model loading,
preprocessing, inference, prediction, and explanation — so it's just as easy
to walk a mentor through the backend as the frontend.

```bash
pip install fastapi uvicorn python-multipart
uvicorn demo.api:app --reload --port 8000
```

Check it's alive: open `http://localhost:8000/health` — it reports whether a
trained checkpoint was actually found, so you always know if you're serving
real predictions or an untrained placeholder.

Watch the terminal while you send a request — you'll see each stage logged
in order (`STAGE 1 [MODEL LOADING]` ... `STAGE 5 [EXPLANATION]`), which is
useful both for debugging and for showing a mentor the backend is doing real
work, not just returning a canned response.

### Step 4 — Presentation demo (`demo/app.html`, `demo/live_call_app.html`)
A single-file browser page with a record/upload button and a risk-score display.
Open `demo/app.html`'s comments — it's currently wired to **mock/sample scores** so it
works standalone for rehearsal. Swap the `scoreAudio()` function to call your real
`infer.py` (wrapped in a tiny Flask/FastAPI endpoint) once your model is trained, and it
becomes a genuine live demo.

## Honest scope note

Given the lab time available, aim for **one language done well** (Hindi has the most
Common Voice data) rather than three done thinly. Mention Kannada/Tamil as "designed to
extend to" in your presentation if you don't have time to fully validate them — that's a
credible, honest framing that still shows the multilingual design intent.

## What to say in your presentation
1. The problem (cite the SEBI/RBI advisories — see PROJECT_PROPOSAL.docx).
2. Why this is hard for Indian languages specifically (data scarcity vs. English/Mandarin).
3. Your architecture (one slide, the diagram from the proposal doc).
4. Your numbers (EER, accuracy — from `metrics.json`).
5. Live demo.
6. Limitations, next steps.
